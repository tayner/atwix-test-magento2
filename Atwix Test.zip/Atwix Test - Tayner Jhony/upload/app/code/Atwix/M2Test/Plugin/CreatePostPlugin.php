<?php

namespace Atwix\M2Test\Plugin;

use Magento\Customer\Controller\Account\CreatePost;
use Magento\Customer\Model\Session;
use Psr\Log\LoggerInterface as PsrLoggerInterface;
use Atwix\M2Test\Model\Email\Customer\SendInfoInterface;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Plugin to manipulate actions to create user
 */
class CreatePostPlugin
{
    /** @var Session */
    private Session $customerSession;

    /**
     * @var PsrLoggerInterface
     */
    private $logger;

    /**
     * @var SendInfoInterface
     */
    private SendInfoInterface $customerEmail;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @param Session $customerSession
     * @param PsrLoggerInterface $logger
     * @param SendInfoInterface $customerEmail
     * @param Json $json
     */
    public function __construct(
        Session $customerSession,
        PsrLoggerInterface $logger,
        SendInfoInterface $customerEmail,
        Json $json
    ) {
        $this->customerSession = $customerSession;
        $this->logger = $logger;
        $this->customerEmail = $customerEmail;
        $this->json = $json;
    }

    /**
     * After success created a new user
     *
     * @param CreatePost $subject
     * @param $result
     *
     * @return mixed
     */
    public function afterExecute(
        CreatePost $subject,
        $result
    ) {
        /** @var Session $lastUserCreated */
        $lastUserCreated = $this->customerSession->getCustomer();

        $customerBasicInfo = ['firstName' => $lastUserCreated->getFirstname(),
                               'lastName' => $lastUserCreated->getLastname(),
                                  'email' => $lastUserCreated->getEmail()
                              ];

        /** Send a customer email with basics info*/
        $this->customerEmail->sendInfo($customerBasicInfo);

        /** Write log data*/
        $this->logger->info($this->json->serialize($customerBasicInfo));

        return $result;
    }
}
