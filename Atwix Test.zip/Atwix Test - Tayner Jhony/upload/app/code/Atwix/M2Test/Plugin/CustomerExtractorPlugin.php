<?php

namespace Atwix\M2Test\Plugin;

use Closure;
use Magento\Customer\Model\CustomerExtractor;
use Atwix\M2Test\Helper\Form\FieldsUtil;

/**
 * Responsible to change user names requests
 */
class CustomerExtractorPlugin
{
    /** @var FieldsUtil*/
    private FieldsUtil $fieldsUtil;

    /**
     * @param FieldsUtil $fieldsUtil
     */
    public function __construct(
        FieldsUtil $fieldsUtil
    ){
        $this->fieldsUtil = $fieldsUtil;
    }

    /**
     * Around Extract Field to remove whitespaces for name
     *
     * @param CustomerExtractor $subject
     * @param Closure $closure
     * @param $formCode
     * @param $request
     *
     *
     * @return bool|string
     */
    public function aroundExtract(
        CustomerExtractor $subject,
        Closure $closure,
        $formCode,
        $request
    ){


        if (!is_null($firstName = $request->getParam('firstname'))) {
            $nameWithoutSpaces = $this->fieldsUtil->removeSpaces($firstName);
            $request->setParams(['firstname' => $nameWithoutSpaces]);
        }

        return $closure($formCode,$request);
    }
}
