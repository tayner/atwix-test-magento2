<?php

namespace Atwix\M2Test\Helper\Form;

use Magento\Framework\App\Helper\AbstractHelper;

/**
 * Classe Responsible to Fields util functions
 */
class FieldsUtil extends AbstractHelper
{
    /**
     * Function to remove a field white space
     *
     * @param string $field
     *
     * @return string;
     */
    public function removeSpaces(string $field): string
    {
        return str_replace(' ', '', $field);
    }
}
