<?php

namespace Atwix\M2Test\Helper\Store;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

/**
 * Classe Responsible to store util info
 */
class InfoUtil extends AbstractHelper
{
    public const TRANS_EMAIL_EMAIL = 'trans_email/ident_sales/email';
    public const TRANS_EMAIL_NAME = 'trans_email/ident_sales/name';

    /**
     * Return Customer Support email
     *
     * @return string
     */
    public function getStoreEmail(): string
    {
        return $this->scopeConfig->getValue(
            self::TRANS_EMAIL_EMAIL,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return Customer Support Name
     *
     * @return string
     */
    public function getStorename(): string
    {
        return $this->scopeConfig->getValue(
            self::TRANS_EMAIL_NAME,
            ScopeInterface::SCOPE_STORE
        );
    }
}
