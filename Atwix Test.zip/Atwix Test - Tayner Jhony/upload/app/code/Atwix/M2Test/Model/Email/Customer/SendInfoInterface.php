<?php

namespace Atwix\M2Test\Model\Email\Customer;

/**
 * Contract file to send info
 */
interface SendInfoInterface
{
    /**
     * @param array $data
     *
     * @return void
     */
    public function sendInfo(array $data): void;
}
