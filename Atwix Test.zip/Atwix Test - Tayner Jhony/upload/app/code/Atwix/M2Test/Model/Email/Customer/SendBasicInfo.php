<?php

namespace Atwix\M2Test\Model\Email\Customer;

use Magento\Framework\App\Area;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Mail\Template\TransportBuilderFactory;
use Magento\Framework\Model\AbstractModel;
use Magento\Store\Model\Store;
use Atwix\M2Test\Helper\Store\InfoUtil as HelperStoreInfoUtil;

/**
 * Send the basic info to final customer
 */
class SendBasicInfo  extends AbstractModel implements SendInfoInterface
{
    public const TEMPLATE_EMAIL = 'customer_basic_information_email';

    /**
     * @var TransportBuilderFactory
     */
    private TransportBuilderFactory $emailTransportBuilderFactory;

    /**
     * @var HelperStoreInfoUtil
     */
    private HelperStoreInfoUtil $helperStoreInfoUtil;

    /**
     * @param TransportBuilderFactory $emailTransportBuilderFactory
     * @param HelperStoreInfoUtil $helperStoreInfoUtil
     */
    public function __construct(
        TransportBuilderFactory $emailTransportBuilderFactory,
        HelperStoreInfoUtil $helperStoreInfoUtil
    ) {
        $this->emailTransportBuilderFactory = $emailTransportBuilderFactory;
        $this->helperStoreInfoUtil = $helperStoreInfoUtil;
    }

    /**
     * Responsible to send an email
     *
     * @param array $data
     *
     * @throws LocalizedException
     * @throws MailException
     */
    public function sendInfo(array $data): void
    {
        $emailTransportBuilder = $this->emailTransportBuilderFactory->create();
        $emailTransportBuilder->addTo(
            $this->helperStoreInfoUtil->getStoreEmail(),
            $this->helperStoreInfoUtil->getStorename()
        );
        $emailTransportBuilder->setFrom('general');

        $emailTransportBuilder->setTemplateIdentifier(self::TEMPLATE_EMAIL);
        $emailTransportBuilder->setTemplateOptions(
            [
                'area'  => Area::AREA_FRONTEND,
                'store' => Store::DEFAULT_STORE_ID
            ]
        );

        $vars = [
            'customer' => $data
        ];

        $emailTransportBuilder->setTemplateVars($vars);
        $emailTransportBuilder->getTransport()->sendMessage();
    }
}
